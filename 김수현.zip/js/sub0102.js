$(function () {
    $(window).scroll(function () {
        /* section01 animation */
        if ($(this).scrollTop() > 100) {
            $(".line").addClass("on");
        } else {
            $(".line").removeClass("on");
        };
        if ($(this).scrollTop() = 70) {
            $('.counter').each(function () {
                $(this)
                    .prop('Counter', 0)
                    .animate({
                        Counter: $(this).text()
                    }, {
                        duration: 3000,
                        easing: 'swing',
                        step: function (now) {
                            $(this).text(Math.ceil(now))
                        }
                    });
            });
        };
        /* section02 animation */
        if ($(this).scrollTop() > 0) {
            $(".section02_wrap").addClass("on");
        } else {
            $(".section02_wrap").removeClass("on");
        };
    });
});
